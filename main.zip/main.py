#!/bin/bash
import sys
import math


# hyperparameters
ROBOT_RADIUS = 0.45
ROBOT_RHO = 20
ROBOT_NUM = 4
MAP_SIZE = 100
PI = math.pi

# Robots and Craft Tables
class Robot():
    def __init__(self, id):
        self.work_space = -1
        self.take_thing = 0
        self.time_f = 0.0
        self.crush_f = 0.0
        self.angle_speed = 0.0
        self.line_speed_x, self.line_speed_y = 0.0, 0.0
        self.toward = 0.0
        self.x, self.y = 0.0, 0.0
        self.robot_id = id
        # work_frame means start work from this frame
        # state 0 means staying
        # state 1 means walking towards the workbench
        # state 2 means buy the original things
        # state 3 means waiting for the produce
        # state 4 means walking towards the sell things
        # state 5 means sell the things
        # TODO::state 6 means 
        self.work_frame = 1
        self.state = 0
        # next target workbench
        self.target_workbench_ids=-1

    def get_from_frame(self, work_space, take_thing, time_f, crush_f, angle_speed, line_speed_x, line_speed_y, toward, x, y):
        self.work_space = int(work_space)
        self.take_thing = int(take_thing)
        self.time_f = float(time_f)
        self.crush_f = float(crush_f)
        self.angle_speed = float(angle_speed)
        self.line_speed_x, self.line_speed_y = float(line_speed_x), float(line_speed_y)
        self.toward = float(toward)
        self.x, self.y = float(x), float(y)

    def rotate_to_target(self, target_x, target_y):
        R_W_angle = math.atan2(target_y - self.y, target_x - self.x) - self.toward
        if R_W_angle < 0:
            speed = max(-PI, R_W_angle * 50)
        else:
            speed = min(PI, R_W_angle * 50)
        sys.stdout.write('rotate %d %f\n' % (self.robot_id, speed))
        if R_W_angle < 0.0001:
            R_W_angle=0
        return R_W_angle

    def find_nearest_target(self, workbench_frame_num, workbenchs, target_workbench_list, take_thing):
        target_workbench_distance=300
        for workbench_ids in range(workbench_frame_num):
            # if (workbenchs[workbench_ids].work_type in target_workbench_list) and workbenchs[workbench_ids].is_targeted_flag == 0:
            if ((workbenchs[workbench_ids].work_type in target_workbench_list)):
                # workbench is full
                if ((1 << take_thing) & workbenchs[workbench_ids].origin_thing):
                    continue
                R_W_distance = cal_point_x_y(self.x, self.y, workbenchs[workbench_ids].x, workbenchs[workbench_ids].y)
                if target_workbench_distance > R_W_distance:
                    self.target_workbench_ids, target_workbench_distance = workbench_ids, R_W_distance

class WorkBench():
    def __init__(self, id):
        self.work_type = 0
        self.x, self.y = 0.0, 0.0
        self.remain_time = -1
        self.origin_thing =0
        self.output = 0
        self.table_id = id

        # the workbench is targeted by a robot
        self.is_targeted_flag = 0
    def get_from_frame(self, work_type, x, y, remain_time, origin_thing, output):
        self.work_type = int(work_type)
        self.x, self.y = float(x), float(y)
        self.remain_time = int(remain_time)
        self.origin_thing = int(origin_thing)
        self.output = int(output)


# Calc Functions
def cal_x(row: int):
    return 0.25 + row * 0.50
    
def cal_y(col: int):
    # return 0.25 + col * 0.50
    return 50.00 - (0.25 + col * 0.50)
    
def cal_point_x_y(origin_x: float, origin_y: float, target_x: float, target_y):
    return math.sqrt((origin_x - target_x) ** 2 + (origin_y - target_y) ** 2)


# Input and Output Functions 
def read_map():
    env_mp, row_cnt = [[] for i in range(MAP_SIZE)], 0
    while True:
        line = input()
        if line == "OK":
            break
        for ch in line:
            env_mp[row_cnt].append(ch)
        row_cnt += 1
    return env_mp

def finish():
    sys.stdout.write('OK\n')
    sys.stdout.flush()


# Main
if __name__ == '__main__':
    # input env_map
    env_mp, dis_mp = read_map(), [[50.0 * 50.0 for j in range(50)] for i in range(50)]
    finish()

    # init Craft_Table and robots
    workbench_xynum_dist = {}
    workbench_ids = 0
    workbenchs, robots = [], []
    workbench_type_num = [[] for i in range(10)]
    # start working
    while True:
        line = sys.stdin.readline()
        if not line:
            break
        # input every frame
        parts = line.split(' ')
        frame_id, money_frame = int(parts[0]), int(parts[1])
        if frame_id == 1:
            # 1th frame use init
            workbench_frame_num = int(input())
            for workbench in range(workbench_frame_num):
                workbench_type, workbench_x, workbench_y, workbench_remain, workbench_origin, workbench_output = input().split()
                # create a new craft table
                workbench_xynum_dist[(float(workbench_x), float(workbench_y))] = workbench_ids
                workbenchs.append(WorkBench(workbench_ids))
                workbench_type_num[int(workbench_type)].append(workbench_ids)
                # init it 
                workbenchs[workbench_ids].get_from_frame(workbench_type, workbench_x, workbench_y, workbench_remain, workbench_origin, workbench_output)
                workbench_ids += 1
            
            for robot in range(ROBOT_NUM):
                robot_work, robot_take, robot_time, robot_crush, robot_angle, robot_line_x, robot_line_y, robot_toward, robot_x, robot_y = input().split()
                # create a new robot and init it
                robots.append(Robot(robot))
                robots[robot].get_from_frame(robot_work, robot_take, robot_time, robot_crush, robot_angle, robot_line_x, robot_line_y, robot_toward, robot_x, robot_y)
            # init the distance tables
            
            for workbench_a in range(0, workbench_ids):
                for workbench_b in range(workbench_a + 1, workbench_ids):
                    dis_mp[workbench_a][workbench_b] = dis_mp[workbench_b][workbench_a] = cal_point_x_y(workbenchs[workbench_a].x, workbenchs[workbench_a].y, workbenchs[workbench_b].x, workbenchs[workbench_b].y)

        else:
            # update
            workbench_frame_num = int(input())
            for workbench in range(workbench_frame_num):
                workbench_type, workbench_x, workbench_y, workbench_remain, workbench_origin, workbench_output = input().split()
                # create a new craft table
                workbench_id = workbench_xynum_dist[(float(workbench_x), float(workbench_y))]
                # update it
                workbenchs[workbench_id].get_from_frame(workbench_type, workbench_x, workbench_y, workbench_remain, workbench_origin, workbench_output)
            
            for robot in range(ROBOT_NUM):
                robot_work, robot_take, robot_time, robot_crush, robot_angle, robot_line_x, robot_line_y, robot_toward, robot_x, robot_y = input().split()
                # update the robot state
                robots[robot].get_from_frame(robot_work, robot_take, robot_time, robot_crush, robot_angle, robot_line_x, robot_line_y, robot_toward, robot_x, robot_y)
        line = sys.stdin.readline()

        # do some operation
        sys.stdout.write('%d\n' % frame_id)
        for robot_id in range(ROBOT_NUM):
            if robots[robot_id].work_frame <= frame_id:
                if robots[robot_id].state == 0:
                    # find nearest 1 2 3
                    # sys.stdout.write('forward %d %f\n' % (robot_id, 0))
                    robots[robot_id].find_nearest_target(workbench_frame_num, workbenchs, [1, 2, 3], robots[robot_id].take_thing)
                    workbenchs[robots[robot_id].target_workbench_ids].is_targeted_flag = 1
                    robots[robot_id].state = 1

                elif robots[robot_id].state == 1:
                    # calc the speed and go
                    # reach the target workbench
                    distance = cal_point_x_y(robots[robot_id].x, robots[robot_id].y, workbenchs[robots[robot_id].target_workbench_ids].x, workbenchs[robots[robot_id].target_workbench_ids].y)
                    # adjust the angle
                    R_W_angle = robots[robot_id].rotate_to_target(workbenchs[robots[robot_id].target_workbench_ids].x, workbenchs[robots[robot_id].target_workbench_ids].y)
                    if R_W_angle == 0:
                        # go straight
                        speed = min(6, distance * 50)
                        sys.stdout.write('forward %d %f\n' % (robot_id, speed))
                    else:
                        sys.stdout.write('forward %d %f\n' % (robot_id, 0))
                    # reach the target workbench
                    if distance <= 0.4:
                        sys.stdout.write('forward %d %f\n' % (robot_id, 0))
                        workbenchs[robots[robot_id].target_workbench_ids].is_targeted_flag = 0
                        robots[robot_id].state = 2
                elif robots[robot_id].state == 2:
                    # buy
                    # if workbench is working
                    if workbenchs[robots[robot_id].target_workbench_ids].output == 1 and robots[robot_id].take_thing == 0:
                        sys.stdout.write('buy %d\n' % robot_id)
                    elif workbenchs[robots[robot_id].target_workbench_ids].remain_time > 0:
                        pass
                        # if workbench work ok
                    else:
                        robots[robot_id].state = 3
                elif robots[robot_id].state == 3:
                    # 1 -> 4 5 9 ; 2 -> 4 6 9; 3 -> 5 6 9
                    # find sell place
                    if robots[robot_id].take_thing == 1:
                        # find nearest 4 5 9
                        robots[robot_id].find_nearest_target(workbench_frame_num, workbenchs, [4, 5, 9], robots[robot_id].take_thing)
                    elif robots[robot_id].take_thing == 2:
                        # find nearest 4 6 9
                        robots[robot_id].find_nearest_target(workbench_frame_num, workbenchs, [4, 6, 9], robots[robot_id].take_thing)
                    elif robots[robot_id].take_thing == 3:
                        # find nearest 5 6 9
                        robots[robot_id].find_nearest_target(workbench_frame_num, workbenchs, [5, 6, 9], robots[robot_id].take_thing)
                    robots[robot_id].state = 4
                    workbenchs[robots[robot_id].target_workbench_ids].is_targeted_flag = 1
                    if robots[robot_id].take_thing == 0:
                        robots[robot_id].state = 0
                elif robots[robot_id].state == 4:
                    # calc the speed and go
                    # reach the target workbench
                    distance = cal_point_x_y(robots[robot_id].x, robots[robot_id].y, workbenchs[robots[robot_id].target_workbench_ids].x, workbenchs[robots[robot_id].target_workbench_ids].y)
                    # adjust the angle
                    R_W_angle = robots[robot_id].rotate_to_target(workbenchs[robots[robot_id].target_workbench_ids].x, workbenchs[robots[robot_id].target_workbench_ids].y)
                    if R_W_angle == 0:
                        # go straight
                        speed = min(6, distance * 50)
                        sys.stdout.write('forward %d %f\n' % (robot_id, speed))
                    else:
                        sys.stdout.write('forward %d %f\n' % (robot_id, 0))
                    # reach the target workbench
                    if distance <= 0.4:
                        sys.stdout.write('forward %d %f\n' % (robot_id, 0))
                        workbenchs[robots[robot_id].target_workbench_ids].is_targeted_flag = 0
                        robots[robot_id].state = 5

                elif robots[robot_id].state == 5:
                    # sell and turn 0
                    sys.stdout.write('forward %d %f\n' % (robot_id, 0))
                    sys.stdout.write('rotate %d %f\n' % (robot_id, 0))

                    distance = cal_point_x_y(robots[robot_id].x, robots[robot_id].y, workbenchs[robots[robot_id].target_workbench_ids].x, workbenchs[robots[robot_id].target_workbench_ids].y)
                    if distance > 0.4:
                        robots[robot_id].state == 4
                    # sys.stdout.write('rotate %d %f\n' % (robot_id, 0))
                    else:
                        sys.stdout.write('sell %d\n' % robot_id)
                        # if robots[robot_id].line_speed_x != 0 or robots[robot_id].line_speed_y != 0:
                        #     sys.stdout.write('forward %d %f\n' % (robot_id, 0))
                        # else:
                        #     robots[robot_id].state = 0
                        robots[robot_id].state = 0
        finish()
